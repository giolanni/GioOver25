# GioOver Analysis

Pacchetto di skill/procedura per analizzare in modo ripetibile gli archivi `StoriciRanking*.zip`.

## Contenuto
- `SKILL.md` — protocollo completo GioOver2.5.
- `scripts/analyze_rankings.py` — calcoli deterministici.

## Esempi

Analisi di una giornata:
```bash
python scripts/analyze_rankings.py StoriciRanking.zip --date 2026-09-28
```

Ultimi 10 giorni terminanti il 28/09:
```bash
python scripts/analyze_rankings.py StoriciRanking.zip --date 2026-09-28 --last-days 10
```

Simulazioni vg2/vg3/vg4 sull'intero storico:
```bash
python scripts/analyze_rankings.py StoriciRanking.zip --vg-sim
```

La skill definisce `MatchDate` come data canonica, mantiene vg1 ALTA/IMM separate e usa BTTS come KPI principale di vg1.


Common set (vg1 escluso prima dell'intersezione):
```bash
python scripts/analyze_rankings.py StoriciRanking.zip --common-set
```

Common set senza Australia:
```bash
python scripts/analyze_rankings.py StoriciRanking.zip --common-set --no-australia
```
