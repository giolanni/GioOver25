#!/usr/bin/env python3
"""Deterministic GioOver2.5 historical ranking analyzer."""
from __future__ import annotations
import argparse, io, re, zipfile
from pathlib import Path
import pandas as pd

KEY = ["LeagueId", "MatchDate", "Home", "Away"]

def engine_name(name: str) -> str:
    base = Path(name).name
    return base.replace("storico_ranking_", "").replace(".csv", "")

def load_archive(path: str) -> dict[str, pd.DataFrame]:
    out = {}
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            if not n.lower().endswith(".csv") or "storico_ranking_" not in Path(n).name:
                continue
            raw = z.read(n)
            df = pd.read_csv(io.BytesIO(raw), sep=";", dtype=str, encoding="utf-8-sig")
            df.columns = [c.strip() for c in df.columns]
            if "Score" in df: df["Score_num"] = pd.to_numeric(df["Score"].str.replace(",", ".", regex=False), errors="coerce")
            if "Goals" in df: df["Goals_num"] = pd.to_numeric(df["Goals"].str.replace(",", ".", regex=False), errors="coerce")
            out[engine_name(n)] = df
    return out

def result_stats(s: pd.Series) -> tuple[int,int,int,float|None]:
    s = s.astype(str).str.strip()
    ok = int((s == "OK").sum()); ko = int((s == "KO").sum()); tot = ok + ko
    return ok, ko, tot, (100*ok/tot if tot else None)

def fmt(st):
    ok,ko,n,p=st
    return f"{ok}/{n} OK ({p:.2f}%) [KO={ko}]" if n else "0 eventi"

def alta_o25(df, date=None):
    x=df
    if date: x=x[x["MatchDate"].eq(date)]
    x=x[x["Band"].eq("ALTA")]
    return result_stats(x["Over25"])

def media_o15(df, date=None):
    x=df
    if date: x=x[x["MatchDate"].eq(date)]
    x=x[x["Band"].isin(["MEDIA","MEDIA-ALTA"]) & x["Goals_num"].notna()]
    ok=int((x["Goals_num"]>=2).sum()); ko=int((x["Goals_num"]<2).sum()); n=ok+ko
    return ok,ko,n,(100*ok/n if n else None)

def imm_mask(df):
    return df["Band"].fillna("").str.match(r"^IMM-ALTA-\d+$")

def vg_band(df, mask, date=None):
    x=df[mask].copy()
    if date: x=x[x["MatchDate"].eq(date)]
    return result_stats(x["BTTS"]), result_stats(x["Over25"])

def dedupe(df):
    cols=[c for c in KEY if c in df.columns]
    return df.drop_duplicates(cols) if cols else df

def simulated_vg(df, lo, hi):
    alta=df["Band"].eq("ALTA")
    added=(~alta) & df["Score_num"].ge(lo) & df["Score_num"].lt(hi)
    sel=dedupe(df[alta | added])
    add=dedupe(df[added])
    return {
        "all_btts":result_stats(sel["BTTS"]), "all_o25":result_stats(sel["Over25"]),
        "added_btts":result_stats(add["BTTS"]), "added_o25":result_stats(add["Over25"])
    }

def common_set_stats(engines, no_australia=False):
    base = {e:d.copy() for e,d in engines.items() if e != "vg1"}
    if no_australia:
        base = {e:d[~d["LeagueId"].fillna("").str.startswith("Australia_")].copy() for e,d in base.items()}
    sets = []
    for d in base.values():
        valid=d.dropna(subset=KEY)
        sets.append(set(map(tuple, valid[KEY].astype(str).values.tolist())))
    common=set.intersection(*sets) if sets else set()
    rows=[]
    for e,d in base.items():
        keys=list(map(tuple,d[KEY].astype(str).values.tolist()))
        x=d[pd.Series([k in common for k in keys], index=d.index) & d["Band"].eq("ALTA")]
        rows.append((e, result_stats(x["Over25"])))
    return common, rows

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("archive")
    ap.add_argument("--date", help="YYYY-MM-DD")
    ap.add_argument("--last-days", type=int)
    ap.add_argument("--vg-sim", action="store_true")
    ap.add_argument("--common-set", action="store_true")
    ap.add_argument("--no-australia", action="store_true")
    args=ap.parse_args()
    engines=load_archive(args.archive)
    if not engines: raise SystemExit("Nessun storico_ranking_*.csv trovato")

    # Optional calendar window ending at --date, or at latest MatchDate.
    if args.last_days:
        dates=[]
        for d in engines.values():
            dates += d["MatchDate"].dropna().tolist()
        end=pd.to_datetime(args.date or max(dates))
        start=end-pd.Timedelta(days=args.last_days-1)
        for k in list(engines):
            dt=pd.to_datetime(engines[k]["MatchDate"], errors="coerce")
            engines[k]=engines[k][dt.between(start,end)].copy()
        print(f"WINDOW {start.date()}..{end.date()}")

    print("\nALTA O2.5")
    for e,df in engines.items():
        if e=="vg1": continue
        print(f"{e:20} {fmt(alta_o25(df,args.date if not args.last_days else None))}")

    print("\nMEDIA+MEDIA-ALTA O1.5")
    for e,df in engines.items():
        if e=="vg1": continue
        if "Goals_num" in df:
            print(f"{e:20} {fmt(media_o15(df,args.date if not args.last_days else None))}")

    if args.common_set:
        common, rows=common_set_stats(engines,args.no_australia)
        print(f"\nCOMMON SET non-vg1: {len(common)} partite")
        for e,st in rows:
            print(f"{e:20} {fmt(st)}")

    if "vg1" in engines:
        df=engines["vg1"]
        date=args.date if not args.last_days else None
        print("\nVG1")
        b,o=vg_band(df,df["Band"].eq("ALTA"),date)
        print("ALTA BTTS:",fmt(b),"| O2.5:",fmt(o))
        b,o=vg_band(df,imm_mask(df),date)
        print("IMM  BTTS:",fmt(b),"| O2.5:",fmt(o))
        if args.vg_sim and "Score_num" in df:
            for name,lo,hi in [("vg2",65,70),("vg3",68,72),("vg4",65,72)]:
                r=simulated_vg(df,lo,hi)
                print(f"{name}: BTTS {fmt(r['all_btts'])}; O2.5 {fmt(r['all_o25'])}")
                print(f"  aggiunte: BTTS {fmt(r['added_btts'])}; O2.5 {fmt(r['added_o25'])}")

if __name__=="__main__":
    main()
