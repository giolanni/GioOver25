---
name: gioover-analysis
description: Analizza gli archivi StoriciRanking di GioOver2.5 con regole deterministiche e coerenti.
---

# GioOver Analysis

Usa questa skill quando l'utente carica un archivio `StoriciRanking*.zip` o chiede analisi relative ai ranking/engine GioOver2.5.

## Principio fondamentale
Precisione dei conteggi > velocità. Non riutilizzare percentuali di analisi precedenti se è disponibile un archivio più recente: ricalcolare sempre dai CSV.

## Regole dati
1. La data temporale canonica è `MatchDate`. Non usare `PredictionDate` per filtrare le giornate.
2. Identificativo partita: `LeagueId + MatchDate + Home + Away`.
3. Per statistiche Over2.5 considerare solo righe con `Over25` esattamente `OK` o `KO`.
4. Per BTTS considerare solo righe con `BTTS` esattamente `OK` o `KO`.
5. Non trasformare righe senza esito in KO.
6. Prima di pubblicare una percentuale verificare sempre OK + KO = totale.
7. Mostrare sempre OK, KO, totale e percentuale. Un 100% con campione minuscolo va esplicitamente segnalato.

## Engine ordinari
### ALTA
Per tutti gli engine diversi da vg1:
- selezione: `Band == "ALTA"`
- KPI: Over2.5
- output: OK, KO, totale, % OK.

### MEDIA / MEDIA-ALTA
Per analisi O1.5:
- selezione: `Band in {"MEDIA", "MEDIA-ALTA"}`
- esito O1.5 ricostruito da `Goals`
- OK se `Goals >= 2`
- KO se `Goals < 2`
- ignorare Goals non numerico/mancante.

## Australia
Se richiesto "senza Australia", escludere `LeagueId` che inizia con `Australia_`.

## Common set
Quando si confrontano engine sul set comune:
1. ESCLUDERE `vg1` prima di costruire l'intersezione.
2. Costruire la chiave `LeagueId + MatchDate + Home + Away`.
3. Intersecare le partite presenti nei restanti engine.
4. Calcolare poi le statistiche ALTA di ciascun engine limitatamente a tale intersezione.
5. Non confondere il filename `vg1` con `g1`.

## vg1
`vg1` è un engine BTTS.

### KPI principale
BTTS. Over2.5 va riportato come metrica secondaria quando utile.

### Fasce
Tenere SEMPRE separate:
- `ALTA`
- `IMM-ALTA-*`

Non aggregarle salvo richiesta esplicita.

Per ciascuna riportare:
- BTTS OK/KO/totale/%
- Over2.5 OK/KO/totale/%

### MEDIA vg1 e score
Quando si studiano intervalli di Score, usare intervalli semiaperti salvo diversa richiesta:
- 65/70 = `65 <= Score < 70`
- 68/72 = `68 <= Score < 72`
- 65/72 = `65 <= Score < 72`

Per gli esperimenti sotto, aggiungere soltanto partite non già ALTA; evitare doppi conteggi tramite chiave partita.

## Engine simulati BTTS
- vg2 = ALTA originale vg1 + partite non-ALTA con `65 <= Score < 70`
- vg3 = ALTA originale vg1 + partite non-ALTA con `68 <= Score < 72`
- vg4 = ALTA originale vg1 + partite non-ALTA con `65 <= Score < 72`

Per vg2/vg3/vg4:
- KPI principale BTTS
- riportare anche O2.5 sulle stesse selezioni
- mostrare separatamente rendimento delle sole partite aggiunte
- ricordare che vg2 e vg3 si sovrappongono tra Score 68 e 70; vg4 è l'unione, non la somma dei volumi.

## Analisi giornaliera standard
Quando l'utente dice "solita analisi" per una data:
1. Engine ordinari: ALTA O2.5 per tutti.
2. Ordinare/interpretare considerando precisione E volume, non solo la percentuale.
3. MEDIA + MEDIA-ALTA O1.5.
4. vg1: ALTA BTTS/O2.5 e IMM-ALTA BTTS/O2.5 separate.
5. Se gli esperimenti vg2/vg3/vg4 sono attivi nel contesto, riportare eventuali nuove selezioni/rendimento quando rilevante.
6. Evidenziare campioni piccoli.

## Ultimi N giorni
Usare N date di calendario su `MatchDate`, inclusa la data finale richiesta. Non usare "ultime N righe" o `PredictionDate`.

## Ranking interpretativo
Non proclamare automaticamente migliore il 100% con meno eventi.
Preferire formulazioni del tipo:
- "più preciso nel campione"
- "miglior compromesso precisione/volume"
- "segnale interessante ma campione piccolo"
Non inventare una funzione di scoring se l'utente non la richiede.

## Controlli obbligatori prima della risposta
- archivio più recente corretto
- filename/engine corretti
- filtro MatchDate corretto
- fasce esatte
- OK/KO soltanto
- nessun doppio conteggio
- percentuali ricalcolate da conteggi interi
- vg1 ALTA e IMM separate
- volume esplicitato
